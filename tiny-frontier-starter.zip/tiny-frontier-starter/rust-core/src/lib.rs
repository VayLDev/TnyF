use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub struct GameCore {
    hunger: f32,
    thirst: f32,
    stamina: f32,
    health: f32,
}

#[wasm_bindgen]
impl GameCore {
    #[wasm_bindgen(constructor)]
    pub fn new() -> GameCore {
        GameCore {
            hunger: 100.0,
            thirst: 100.0,
            stamina: 100.0,
            health: 100.0,
        }
    }

    // dt is elapsed time in seconds. This is intentionally a simple prototype model.
    pub fn tick(&mut self, dt: f32, running: bool) {
        let dt = dt.clamp(0.0, 0.25);
        self.hunger = (self.hunger - 0.10 * dt).max(0.0);
        self.thirst = (self.thirst - 0.18 * dt).max(0.0);

        if running {
            self.stamina = (self.stamina - 12.0 * dt).max(0.0);
        } else {
            self.stamina = (self.stamina + 7.0 * dt).min(100.0);
        }

        if self.hunger <= 0.0 || self.thirst <= 0.0 {
            self.health = (self.health - 1.5 * dt).max(0.0);
        }
    }

    pub fn eat(&mut self) {
        self.hunger = (self.hunger + 30.0).min(100.0);
    }

    pub fn drink(&mut self) {
        self.thirst = (self.thirst + 35.0).min(100.0);
    }

    pub fn hunger(&self) -> f32 { self.hunger }
    pub fn thirst(&self) -> f32 { self.thirst }
    pub fn stamina(&self) -> f32 { self.stamina }
    pub fn health(&self) -> f32 { self.health }
}
