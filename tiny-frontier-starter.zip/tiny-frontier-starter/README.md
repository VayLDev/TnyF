# Tiny Frontier — Web + Rust Starter

A browser-first 3D survival prototype intended to be packaged for Android with a WebToAPK-style wrapper.

## Stack
- Three.js + TypeScript + Vite for 3D rendering and UI
- Rust + WebAssembly for survival simulation logic
- WebGL 2 renderer with configurable shadow quality

## Requirements
- Node.js 20+
- Rust stable
- `wasm-pack` (`cargo install wasm-pack`)
- A modern browser with WebGL 2

## Run locally

From `web/`:

```bash
npm install
npm run build:wasm
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
```

The deployable website is generated in `web/dist/`. Host that folder on HTTPS, then point your WebToAPK tool at the hosted URL.

## Android / WebToAPK notes
- Enable JavaScript and WebGL hardware acceleration in the wrapper.
- Use an HTTPS URL.
- Prefer Android System WebView / Chrome WebView with WebGL 2 support.
- Test on real devices. Some WebToAPK services have their own restrictions around WebGL, fullscreen, orientation and local storage.
- This starter does not contain Montenyon OAuth credentials or production API endpoints. Account integration should be added after the Montenyon Account OAuth/OIDC endpoints and redirect URI are known.

## Controls
- Desktop: WASD / arrow keys to move; drag to orbit camera; mouse wheel to zoom.
- Mobile: use the on-screen joystick and action button.
- Settings: quality, shadows, render scale, sound placeholder.

## Current prototype scope
- Low-poly island terrain, water, trees, rocks and a third-person player placeholder
- Directional sunlight and shadow maps
- Day/night time-of-day control
- Rust-powered hunger/thirst/stamina simulation
- Local prototype state only

This is a foundation, not a finished game. Character models, animations, crafting, building, world persistence, secure account integration and cloud saves remain planned work.
