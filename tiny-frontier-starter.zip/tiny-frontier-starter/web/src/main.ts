import * as THREE from "three";
import init, { GameCore } from "./wasm/tiny_frontier_core";
import "./style.css";

const root = document.querySelector<HTMLDivElement>("#game")!;
const app = document.createElement("div");
app.className = "app";
root.appendChild(app);

app.innerHTML = `
  <div class="topbar">
    <div class="brand"><span class="brand-mark">TF</span><div><b>TINY FRONTIER</b><small>MONTE NYON GAMES</small></div></div>
    <div class="top-actions"><button id="settingsBtn" class="icon-btn" aria-label="Settings">⚙</button></div>
  </div>
  <div class="hud">
    <div class="status"><span>♥</span><div><label>HEALTH</label><div class="meter"><i id="healthBar"></i></div></div></div>
    <div class="status"><span>◉</span><div><label>HUNGER</label><div class="meter"><i id="hungerBar"></i></div></div></div>
    <div class="status"><span>≈</span><div><label>THIRST</label><div class="meter"><i id="thirstBar"></i></div></div></div>
    <div class="status"><span>⚡</span><div><label>STAMINA</label><div class="meter"><i id="staminaBar"></i></div></div></div>
  </div>
  <div class="hint">WASD to move · Drag to look · Explore the island</div>
  <div class="mobile-controls">
    <div id="joystick" class="joystick"><div id="stick" class="stick"></div></div>
    <button id="actionBtn" class="action-btn">INTERACT</button>
  </div>
  <div id="settings" class="settings hidden">
    <div class="settings-card">
      <div class="settings-head"><div><small>GAME OPTIONS</small><h2>Settings</h2></div><button id="closeSettings" class="icon-btn">✕</button></div>
      <label class="setting-row">Graphics quality <select id="quality"><option value="low">Low</option><option value="medium" selected>Medium</option><option value="high">High</option></select></label>
      <label class="setting-row">Shadows <input id="shadows" type="checkbox" checked /></label>
      <label class="setting-row">Render scale <select id="scale"><option value="0.65">65%</option><option value="0.8" selected>80%</option><option value="1">100%</option></select></label>
      <label class="setting-row">Look sensitivity <input id="sensitivity" type="range" min="0.4" max="2" step="0.1" value="1" /></label>
      <label class="setting-row">Time of day <input id="timeOfDay" type="range" min="6" max="20" step="0.25" value="14" /></label>
      <p class="setting-note">Higher quality and real-time shadows use more GPU power, especially on mobile.</p>
    </div>
  </div>
  <div class="crosshair">+</div>
`;

const $ = <T extends HTMLElement>(id: string) => app.querySelector<T>(`#${id}`)!;

await init();
const core = new GameCore();

const scene = new THREE.Scene();
scene.background = new THREE.Color("#a9cbd0");
scene.fog = new THREE.Fog("#a9cbd0", 24, 95);

const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 180);
camera.position.set(0, 5, 9);

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.domElement.className = "game-canvas";
app.prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xc8e4ff, 0x66704b, 1.5));
const sun = new THREE.DirectionalLight(0xffe2b4, 3.0);
sun.position.set(-18, 28, 12);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -28;
sun.shadow.camera.right = 28;
sun.shadow.camera.top = 28;
sun.shadow.camera.bottom = -28;
sun.shadow.bias = -0.00015;
scene.add(sun);
scene.add(sun.target);

const groundGeo = new THREE.PlaneGeometry(130, 130, 1, 1);
groundGeo.rotateX(-Math.PI / 2);
const ground = new THREE.Mesh(groundGeo, new THREE.MeshStandardMaterial({ color: "#6f9a67", roughness: 1 }));
ground.receiveShadow = true;
scene.add(ground);

// A simple low-poly island mound.
const island = new THREE.Mesh(
  new THREE.SphereGeometry(1, 10, 7),
  new THREE.MeshStandardMaterial({ color: "#7da66e", flatShading: true, roughness: 1 })
);
island.scale.set(39, 3.2, 34);
island.position.y = -2.4;
island.receiveShadow = true;
scene.add(island);

const water = new THREE.Mesh(
  new THREE.CircleGeometry(58, 48),
  new THREE.MeshStandardMaterial({ color: "#4e9eaa", roughness: 0.28, metalness: 0.05 })
);
water.rotation.x = -Math.PI / 2;
water.position.y = -1.7;
scene.add(water);

function addTree(x: number, z: number, size = 1) {
  const group = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.23, 1.7, 5), new THREE.MeshStandardMaterial({ color: "#72513b", flatShading: true }));
  trunk.position.y = 0.85 * size;
  trunk.scale.setScalar(size);
  trunk.castShadow = true;
  group.add(trunk);
  for (let i = 0; i < 3; i++) {
    const crown = new THREE.Mesh(new THREE.ConeGeometry((1.15 - i * 0.16) * size, 1.8 * size, 6), new THREE.MeshStandardMaterial({ color: i === 0 ? "#397653" : "#4d8b5c", flatShading: true, roughness: 1 }));
    crown.position.y = (1.65 + i * 0.62) * size;
    crown.castShadow = true;
    crown.receiveShadow = true;
    group.add(crown);
  }
  group.position.set(x, 0, z);
  scene.add(group);
}

for (let i = 0; i < 46; i++) {
  const angle = i * 2.399;
  const radius = 8 + (i % 7) * 2.7;
  addTree(Math.cos(angle) * radius, Math.sin(angle) * radius, 0.7 + (i % 4) * 0.12);
}

for (let i = 0; i < 22; i++) {
  const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.45 + (i % 3) * 0.22, 0), new THREE.MeshStandardMaterial({ color: "#858d83", flatShading: true, roughness: 1 }));
  const a = i * 2.1;
  rock.position.set(Math.cos(a) * (5 + i % 6 * 3), 0.1, Math.sin(a) * (5 + i % 6 * 3));
  rock.rotation.set(i, i * 0.4, i * 0.7);
  rock.castShadow = true;
  rock.receiveShadow = true;
  scene.add(rock);
}

// Placeholder third-person character. Replace with an animated GLB character later.
const player = new THREE.Group();
const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.38, 0.85, 4, 7), new THREE.MeshStandardMaterial({ color: "#d18b55", flatShading: true }));
body.position.y = 0.95;
body.castShadow = true;
player.add(body);
const head = new THREE.Mesh(new THREE.IcosahedronGeometry(0.32, 1), new THREE.MeshStandardMaterial({ color: "#e5b88b", flatShading: true }));
head.position.y = 1.75;
head.castShadow = true;
player.add(head);
player.position.set(0, 0, 0);
scene.add(player);

const keys = new Set<string>();
addEventListener("keydown", e => keys.add(e.key.toLowerCase()));
addEventListener("keyup", e => keys.delete(e.key.toLowerCase()));

let yaw = 0, pitch = 0.24, distance = 7, lookSensitivity = 1;
let dragging = false, lastX = 0, lastY = 0;
renderer.domElement.addEventListener("pointerdown", e => { dragging = true; lastX = e.clientX; lastY = e.clientY; renderer.domElement.setPointerCapture(e.pointerId); });
renderer.domElement.addEventListener("pointerup", () => dragging = false);
renderer.domElement.addEventListener("pointermove", e => {
  if (!dragging) return;
  yaw -= (e.clientX - lastX) * 0.005 * lookSensitivity;
  pitch = THREE.MathUtils.clamp(pitch + (e.clientY - lastY) * 0.003 * lookSensitivity, -0.05, 0.85);
  lastX = e.clientX; lastY = e.clientY;
});
renderer.domElement.addEventListener("wheel", e => distance = THREE.MathUtils.clamp(distance + e.deltaY * 0.008, 4, 12));

let joystickX = 0, joystickY = 0;
const joy = $("joystick");
const stick = $("stick");
joy.addEventListener("pointermove", e => {
  if (e.buttons === 0) return;
  const r = joy.getBoundingClientRect();
  const dx = e.clientX - (r.left + r.width / 2);
  const dy = e.clientY - (r.top + r.height / 2);
  const len = Math.max(1, Math.hypot(dx, dy));
  const nx = dx / len * Math.min(len, 38);
  const ny = dy / len * Math.min(len, 38);
  joystickX = nx / 38; joystickY = ny / 38;
  stick.style.transform = `translate(${nx}px, ${ny}px)`;
});
const resetJoy = () => { joystickX = 0; joystickY = 0; stick.style.transform = "translate(0,0)"; };
joy.addEventListener("pointerup", resetJoy);
joy.addEventListener("pointercancel", resetJoy);
joy.addEventListener("pointerleave", e => { if (e.buttons === 0) resetJoy(); });

let quality: "low" | "medium" | "high" = "medium";
function applySettings() {
  const shadows = ($("shadows") as HTMLInputElement).checked;
  const scale = Number(($("scale") as HTMLSelectElement).value);
  quality = ($("quality") as HTMLSelectElement).value as typeof quality;
  renderer.shadowMap.enabled = shadows && quality !== "low";
  sun.castShadow = renderer.shadowMap.enabled;
  sun.shadow.mapSize.set(quality === "high" ? 2048 : quality === "medium" ? 1024 : 512, quality === "high" ? 2048 : quality === "medium" ? 1024 : 512);
  renderer.setPixelRatio(Math.min(devicePixelRatio * scale, quality === "high" ? 2 : quality === "medium" ? 1.5 : 1));
  lookSensitivity = Number(($("sensitivity") as HTMLInputElement).value);
}
$("settingsBtn").addEventListener("click", () => $("settings").classList.remove("hidden"));
$("closeSettings").addEventListener("click", () => $("settings").classList.add("hidden"));
["quality", "shadows", "scale", "sensitivity"].forEach(id => $(id).addEventListener("change", applySettings));
applySettings();

$("actionBtn").addEventListener("click", () => {
  // Temporary interaction: gather a small amount of food/water for UI testing.
  core.eat(); core.drink();
});

const bars = {
  health: $("healthBar"), hunger: $("hungerBar"), thirst: $("thirstBar"), stamina: $("staminaBar")
};
function setBar(el: HTMLElement, value: number) { el.style.width = `${Math.max(0, Math.min(100, value))}%`; }

let previous = performance.now();
function animate(now: number) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - previous) / 1000, 0.05);
  previous = now;

  const forward = (keys.has("w") || keys.has("arrowup") ? 1 : 0) - (keys.has("s") || keys.has("arrowdown") ? 1 : 0) - joystickY;
  const side = (keys.has("d") || keys.has("arrowright") ? 1 : 0) - (keys.has("a") || keys.has("arrowleft") ? 1 : 0) + joystickX;
  const moving = Math.abs(forward) + Math.abs(side) > 0.05;
  const running = keys.has("shift") && moving;
  const speed = running ? 6.2 : 3.4;
  const direction = new THREE.Vector3(side, 0, -forward).normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
  if (moving) {
    player.position.addScaledVector(direction, speed * dt);
    player.rotation.y = Math.atan2(direction.x, direction.z);
  }
  player.position.x = THREE.MathUtils.clamp(player.position.x, -29, 29);
  player.position.z = THREE.MathUtils.clamp(player.position.z, -26, 26);

  core.tick(dt, running);
  setBar(bars.health, core.health());
  setBar(bars.hunger, core.hunger());
  setBar(bars.thirst, core.thirst());
  setBar(bars.stamina, core.stamina());

  const time = Number(($("timeOfDay") as HTMLInputElement).value);
  const daylight = THREE.MathUtils.clamp(Math.sin((time - 6) / 14 * Math.PI), 0.12, 1);
  sun.intensity = 0.35 + daylight * 2.7;
  sun.position.set(-18 + (time - 12) * 1.2, 10 + daylight * 20, 12);
  scene.background = new THREE.Color().lerpColors(new THREE.Color("#172638"), new THREE.Color("#a9cbd0"), daylight);
  scene.fog.color.copy(scene.background);

  const target = player.position.clone().add(new THREE.Vector3(0, 1.2, 0));
  const offset = new THREE.Vector3(Math.sin(yaw) * distance, 2.1 + pitch * 5, Math.cos(yaw) * distance);
  camera.position.lerp(target.clone().add(offset), 1 - Math.pow(0.001, dt));
  camera.lookAt(target);
  renderer.render(scene, camera);
}
requestAnimationFrame(animate);

addEventListener("resize", () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
  applySettings();
});
